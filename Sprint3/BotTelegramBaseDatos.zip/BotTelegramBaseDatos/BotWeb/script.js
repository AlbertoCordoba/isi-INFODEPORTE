document.addEventListener("DOMContentLoaded", () => {
    const navLinks = document.querySelectorAll("nav a");
    const sections = document.querySelectorAll(".section");

    navLinks.forEach(link => {
        link.addEventListener("click", (event) => {
            event.preventDefault();

            // Obtener el ID de la sección a mostrar
            const sectionId = link.getAttribute("data-section");

            // Ocultar todas las secciones
            sections.forEach(section => {
                section.classList.add("hidden");
            });

            // Mostrar la sección seleccionada
            const targetSection = document.getElementById(sectionId);
            if (targetSection) {
                targetSection.classList.remove("hidden");
            }
        });
    });
});